﻿namespace Samples.Models
{
    public class Image
    {
        public int size { get; set; }
        public string url { get; set; }
    }
}