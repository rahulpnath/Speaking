﻿namespace Samples.Models
{
    public class Filters
    {
        public bool category { get; set; }
        public bool exclude { get; set; }
    }
}