﻿namespace SampleNew.Model
{
    public class Image
    {
        public int size { get; set; }
        public string url { get; set; }
        public string https_url { get; set; }
    }
}